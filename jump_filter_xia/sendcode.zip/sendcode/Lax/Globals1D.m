 global limitertype
